<?php
require_once("../connection.php");
require_once("../validation.php");
//Required Validation
if(isset($_POST)){
    $validationStatus=validation(['student_id','datetime','present','remark'],$_POST);
    if(count($validationStatus)){
        $return= [
            "status"=>0,
            "data"=>"",
            "message"=>implode(',',$validationStatus)." Required"
        ];
        return print_r(json_encode($return));    
    }

    //Student create
    $sql = "INSERT INTO attendance (student_id, datetime, present,remark) VALUES (?,?,?,?)";
    $conn->prepare($sql)->execute([$_POST['student_id'],date('Y-m-d',strtotime($_POST['datetime'])),$_POST['present'],$_POST['remark']]);
    $return= [
        "status"=>1,
        "data"=>"",
        "message"=>"Added Successfully"
    ];
    return print_r(json_encode($return));
}
$return= [
    "status"=>0,
    "data"=>"",
    "message"=>"Method not allowed"
];
return print_r(json_encode($return));
    


?>