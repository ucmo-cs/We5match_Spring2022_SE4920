<?php
require_once("../connection.php");
require_once("../validation.php");
$query="select * from employees e inner join users u on u.user_id=e.emp_id ";
$stmt = $conn->query($query);
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

$return= [
    "status"=>1,
    "data"=>$result,
    "message"=>"Employee List"
];
return print_r(json_encode($return));

?>